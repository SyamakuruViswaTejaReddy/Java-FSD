package deepb;

public class AccessSpecifiers {
	protected int a;
	private int p;
	public AccessSpecifiers(int a,int p) {
		this.a=a;
		this.p=p;
	}
	public int getA() {
    	return a;
    }
	public int getP() {
    	return p;
    }
}
