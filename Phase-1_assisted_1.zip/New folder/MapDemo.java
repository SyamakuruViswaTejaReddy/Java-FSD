//write a program in java to verify implementations of Maps
package deepic;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {
		//Hash Map
		System.out.println("HashMap Demo");
		HashMap<Integer,String> hmap=new HashMap<Integer, String>();
		hmap.put(1, "A");
		hmap.put(2, "B");
		hmap.put(3, "C");
		System.out.println("Get element at key 1: "+hmap.get(1));//get() method is used for getting value by passing its key
		System.out.println("Get element at key 2: "+hmap.get(2));
		System.out.println("Get element at key 3: "+hmap.get(3));
		hmap.put(null, null);//both key and value are null
		System.out.println("Get element at key Null: "+hmap.get(null));
		hmap.put(4, null); //key is not null but value is null
		//hmap.put(null, "E");key is null but value is not null,so it cannot be  added in map
		hmap.put(5, "F");
		System.out.println(hmap);
		hmap.remove(5);//It removes the key-value which is stored in the key 5 
		System.out.println("After removing:"+hmap);
		///iterate using for loop
		for (Map.Entry m:hmap.entrySet()) {
			System.out.println(m.getKey()+ " , "+m.getValue());
		}
		System.out.println("HashMap Demo Ends...");
		
		//Hash Table
		System.out.println("HashTable Demo");
		Hashtable<Integer,String> htab=new Hashtable<Integer, String>();
		htab.put(1, "Sun");
		htab.put(2, "Mon");
		htab.put(3, "Tue");
		System.out.println("Get element at key 1: "+htab.get(1));//get() method is used for getting value by passing its key
		System.out.println("Get element at key 2: "+htab.get(2));
		System.out.println("Get element at key 3: "+htab.get(3));
		//htab.put(null, null);//both key and value are null are not accepted
		//System.out.println("Get element at key Null: "+htab.get(null));// Shows Error
		//htab.put(4, null); //key is not null but value is null not accepted
		//htab.put(null, "E");key is null but value is not null,so not accepted
		//Either the key is null or the value is null both are not accepted.
		htab.put(5, "SAT");
		System.out.println(htab);
		htab.remove(5);//It removes the key-value which is stored in the key 5 
		System.out.println("After removing:"+htab);
		///iterate using for loop
		for (Map.Entry m:htab.entrySet()) {
			System.out.println(m.getKey()+ " , "+m.getValue());
		}
		System.out.println("HashTable Demo Ends...");
		     
		//Tree Map
		System.out.println("TreeMap Demo");
		TreeMap<Integer, String> tmap= new TreeMap<Integer, String>();
		tmap.put(1, "Jan");
		tmap.put(2, "Feb");
		tmap.put(3, "Mar");
		System.out.println("Get element at key 1: "+tmap.get(1));//get() method is used for getting value by passing its key
		System.out.println("Get element at key 2: "+tmap.get(2));
		System.out.println("Get element at key 3: "+tmap.get(3));
		//tmap.put(null, null);//both key and value are null are not accepted
		//System.out.println("Get element at key Null: "+tmap.get(null));// Shows Error
		tmap.put(4, null); //key is not null but value is null
	    //tmap.put(null, "E");key is null but value is not null,so not accepted
		tmap.put(5, "Dec");
		System.out.println(tmap);
		tmap.remove(5);//It removes the key-value which is stored in the key 5 
		System.out.println("After removing:"+tmap);
		///iterate using for loop
		for (Map.Entry m:tmap.entrySet()) {
			System.out.println(m.getKey()+ " , "+m.getValue());
		}
		System.out.println("TreeMap Demo Ends...");
	}

}
