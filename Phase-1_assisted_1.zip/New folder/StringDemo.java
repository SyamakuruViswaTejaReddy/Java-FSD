//Write a program to create Strings and display the conversion of Strings to StringBuffer and StringBuilder
package deepic;

public class StringDemo {

	public static void main(String[] args) {
		//String
		 System.out.println("Strings...");
		 String str= new String("Hello World");
		 String str1= "Hello World...";//Strings are immutable...
		 System.out.println(str);
		 System.out.println(str1);
		 //convert string to string buffer
		 System.out.println("String Buffer...");
		 StringBuffer s1= new StringBuffer(str);//stringBuffer is mutable
		 System.out.println("Size: "+s1.length());
		 //it appends welcome to the Hello World
		 s1.append("java");
		 System.out.println("After append:"+s1);
		 //it insert space at 4 position
		 s1.insert(4, " ");
		 System.out.println("after space insertion at 4 position:"+s1);
		 //it will replace string from 5 to 8
		 s1.replace(5, 8, "hey");
		 System.out.println("After Replacing:"+s1);
		 //it can reverse the string
		 s1.reverse();
		 System.out.println("After reversing:"+s1);
		 String st= new String("welcome java");
		 
		 //convert the string to string builder
		 System.out.println("String Builder...");
		 StringBuilder s= new StringBuilder(st);
		 System.out.println("Size: "+s.length());
		 //it appends welcome to the welcome java
		 s.append("Welcome");
		 System.out.println(s);
		 //it insert space at 6 position
		 s.insert(6, " ");
		 System.out.println(s);
		 //it will replace string from 6 to 9
		 s.replace(6, 9, "hii");
		 System.out.println(s);
		//it can reverse the string
	    s.reverse();
		System.out.println(s1);

	}

}
