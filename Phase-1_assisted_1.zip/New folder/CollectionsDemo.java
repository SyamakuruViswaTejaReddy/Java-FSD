//write a program in java to verify implementations of collections
package deepic;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

public class CollectionsDemo {

	public static void main(String[] args) {
		// Collection extends list,queue,set
		// list implementes ArrayList,Vector,Linked list
		//ArrayList Implementation
		System.out.println("List Demo");
		System.out.println("Array list Demo");
		ArrayList<String> arr=new ArrayList<String>();
		//Add the elements to arraylist
		arr.add("first");
		arr.add("second");
		arr.add("third");
		arr.add("fourth");
		arr.add("fifth");
		System.out.println("Array list Values:"+arr);
		//Operations on ArrayList 
		//To Know size of the Arraylist
		System.out.println("Array list size:"+arr.size());
		//To retrive the element at Particular index
		System.out.println("Index[3]:"+arr.get(3));
		//Search the particular element whether it is availabe or not
		System.out.println("Element first Contains or not(true/false):"+arr.contains("first"));
		System.out.println("Element sixth Contains or not(true/false):"+arr.contains("sixth"));
		//To remove a element at an index
		System.out.println("Removed at index[0]:"+arr.remove(0));
		//To remove an object 
		System.out.println("second removed(true/false):"+arr.remove("second"));
		System.out.println("Using For loop:");
		for(String s:arr)
			System.out.println(s);
		System.out.println("Using Iterator:");
		Iterator<String> atr=arr.iterator();
		while(atr.hasNext())
			System.out.println(atr.next());
		System.out.println("Array list Demo Ends...");
		
		// Vector Implementation
		System.out.println("Vector Demo");
		Vector<String> vec=new Vector<String>();
		//Add the elements to Vector
		vec.add("one");
		vec.add("two");
		vec.add("three");
		vec.add("four");
		vec.add("five");
		System.out.println("Vector list Values:"+vec);
		//Operations on Vector 
		//To Know size of the Vector
		System.out.println("Vector size:"+vec.size());
		//To retrive the element at Particular index
		System.out.println("Index[3]:"+vec.get(3));
		//Search the particular element whether it is availabe or not
		System.out.println("Element first Contains or not(true/false):"+vec.contains("one"));
		System.out.println("Element sixth Contains or not(true/false):"+vec.contains("sixth"));
		//To remove a element at an index
		System.out.println("Removed at index[0]:"+vec.remove(0));
		//To remove an object 
		System.out.println("three removed(true/false):"+vec.remove("three"));
		System.out.println("Using For loop:");
		for(String s:vec)
			System.out.println(s);
		System.out.println("Using Iterator:");
		Iterator<String> itr=vec.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		System.out.println("Vector Demo Ends...");
		
		// Linked list Implementation
		System.out.println("Linkedlist Demo");
		LinkedList<Integer> lin=new LinkedList<Integer>();
		//Add the elements to LinkedList
		lin.add(1);
		lin.add(2);
		lin.add(3);
		lin.add(4);
		lin.add(5);
		System.out.println("Linkedlist Values:"+lin);
		//Operations on Linkedlist 
		//To Know size of the LinkedList
		System.out.println("Linkedlist size:"+lin.size());
		//To retrive the element at Particular index
		System.out.println("Index[3]:"+lin.get(3));
		//Search the particular element whether it is availabe or not
		System.out.println("Element 3 Contains or not(true/false):"+lin.contains(3));
		System.out.println("Element 10 Contains or not(true/false):"+lin.contains(10));
		//To remove a element at an index
		System.out.println("Removed at index[0]:"+lin.remove(0));
		//To remove an object 
		//System.out.println("second removed(true/false):"+vec.remove("second"));
        System.out.println("First Element: "+lin.getFirst());
		System.out.println("Last Element: "+lin.getLast());
		System.out.println("Using For loop:");
		for(int i:lin)
			System.out.println(i);
		System.out.println("Using Iterator:");
		Iterator<Integer> ltr=lin.iterator();
		while(ltr.hasNext())
			System.out.println(ltr.next());
		System.out.println("LinkedList Demo Ends...");
		System.out.println("List Demo Ends...");
		
		//Queue Implements PriorityQueue 
		System.out.println("Queue Demo");
		PriorityQueue<String> pq= new PriorityQueue<String>(); 
		pq.add("Hii");
		pq.add("Hello");
		pq.add("Hey");
		pq.add("Haa");
		System.out.println("Priority Queue Values:"+pq);
	    System.out.println("Top Element: " + pq.peek());
		System.out.println("Printing the top element and removing: "+pq.poll());
		System.out.println("Top Element: " + pq.peek());
		pq.remove("haa");
		System.out.println("After Remove : "+pq);
		System.out.println("Queue Demo Ends");
		
		//Set implements HashSet and Linked HashSet and having treeset implemented by sortedSet
		System.out.println("HashSet Demo");
        HashSet<String> set= new HashSet<String>();
		set.add("Yellow");
		set.add("Yellow");
		set.add("Green");
		set.add("Pink");
		set.add("Blue");
		set.add("Orange");
		set.add("White");
		System.out.println("Size: "+set.size());// It returns 6 because duplicate values are teated to 1 value only in sets. 
		System.out.println(set);
		System.out.println(" orange element Contains: "+ set.contains("Orange"));
		//iterate using for loop
		System.out.println("Using For loop:");
		for(String i:set)
			System.out.println(i);
		//iterate using iterator
		System.out.println("Using Iterator:");
		Iterator<String> htr=set.iterator();
		while(htr.hasNext())
			System.out.println(htr.next());
		
		System.out.println("Linked HashSet Demo:");
        LinkedHashSet<String> lset= new LinkedHashSet<String>();
		lset.add("Jan");
		lset.add("Feb");
		lset.add("Mar");
		lset.add("April");
		lset.add("May");
		lset.add("Feb");
		lset.add(null);//cannot be added because duplicate value
		System.out.println("Size: "+lset.size());//size of the linkedHashSet
		System.out.println("Elements of the LinkedHashset:"+lset);
		System.out.println("Contains May: "+lset.contains("Mar"));
		lset.remove(null);
		lset.remove("April");
		System.out.println("Elements of LinkedHashset after remove operation: "+lset);
		//iterate using for loop
		System.out.println("Using For loop:");
		for(String i:lset)
			System.out.println(i);
		//iterate using iterator
		System.out.println("Using Iterator:");
		Iterator<String> lltr=lset.iterator();
				while(lltr.hasNext())
					System.out.println(lltr.next());
		//Treeset Demo
		System.out.println("TreeSet Demo:");
        Set<String> tree = new TreeSet<String>();//TreeSet is implementation of sortedSet which was extended by set.  
		tree.add("Leaves");
		tree.add("Fruits");
		tree.add("Branch");
		tree.add("Oxygen");
		System.out.println(tree);
		System.out.println("Size: "+tree.size());
		System.out.println("Contains Shade:"+ tree.contains("Shade"));
		tree.remove("Branch");
		System.out.println("After remove operation:"+tree);
		//iterate using for loop
		System.out.println("Using For loop:");
		for(String i:tree)
			System.out.println(i);
		//iterate using iterator
		System.out.println("Using Iterator:");
		Iterator<String> ttr=tree.iterator();
						while(ttr.hasNext())
							System.out.println(ttr.next());
		System.out.println("Set Demo Ends...");
		System.out.println("Collection Demo Ends.....");
	}

}
