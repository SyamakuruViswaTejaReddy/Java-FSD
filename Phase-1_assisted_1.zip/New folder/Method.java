//write a program in java to verify implementations of methods and way of a calling method
package deepic;

import java.util.Scanner;

public class Method {
	public void a() {
		System.out.println("Hii.. without parameters and without return type");
	}
	public void b(int a,int b) {
        int c;
        c=a+b;
        System.out.println("so without return type then i would print here result(Addition):"+c);
	}
	public int c() {
        int d=10,e=25,c;
        c=d+e;
        return c;
	}
	public int d(int a,int b) {
        int c;
        c=a+b;
        return c;
	}

	public static void main(String[] args) {
		Method m=new Method();
		Scanner sin=new Scanner(System.in);
		int a,b;
		System.out.println("Enter a value:");
		a=sin.nextInt();
		System.out.println("Enter b value:");
		b=sin.nextInt();
		sin.close();
		m.a();
		m.b(a,b);
		System.out.println("Without parameter and with return type:"+m.c());
		System.out.println("With parameter and with return type:"+m.d(a,b));
	}

}
