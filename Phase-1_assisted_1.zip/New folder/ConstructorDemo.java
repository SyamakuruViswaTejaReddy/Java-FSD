//write a program in java to verify implementations of constructor types
package deepic;

import java.util.Scanner;

public class ConstructorDemo {
	int a;
	int b;
	int c;
	public ConstructorDemo() {//Default Constructor
		this.a=10;
		this.b=20;
	}
	public ConstructorDemo(int a, int b) {//Parameterized Constructor
		this.a=a;
		this.b=b;
	}
	public int  display() {
		c=a+b;
		return c;
	}
	
	public static void main(String[] args) {
		Scanner sin=new Scanner(System.in);
		int a,b;
		System.out.println("Enter a value:");
		a=sin.nextInt();
		System.out.println("Enter b value:");
		b=sin.nextInt();
		sin.close();
		ConstructorDemo c=new ConstructorDemo();
		ConstructorDemo c1=new ConstructorDemo(a,b);
		System.out.println("Default Constructor Result in Addition:"+c.display());
		System.out.println("parameterized Constructor Result in Addition:"+c1.display());

	}

}
