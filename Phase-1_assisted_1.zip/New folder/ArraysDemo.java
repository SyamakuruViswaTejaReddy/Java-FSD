//write a program in java to verify implementations of Arrays
package deepic;

import java.util.Scanner;

public class ArraysDemo {

	public static void main(String[] args) {
	  int n,r,c;
	  System.out.println("One Dimensinol Array");
	  Scanner sin=new Scanner(System.in);
	  System.out.println("Enter one dimensional array size:");
	  n=sin.nextInt();
	  int arr[]=new int[n];
	  System.out.println("Enter Array Values:");
	  for(int i=0;i<n;i++) {
		  System.out.println("arr["+i+"]:");
		  arr[i]=sin.nextInt();
	  }
	  System.out.println("Array Values are");
	  for(int i=0;i<n;i++) {
	  System.out.println("arr["+i+"]:"+arr[i]);
	  }
	  System.out.println("Multi dimensional array:");
	  System.out.println("Enter Row Size:");
	  r=sin.nextInt();
	  System.out.println("Enter Coloumn Size:");
	  c=sin.nextInt();
	  int ar[][]=new int[r][c];
	  System.out.println("Enter Array Values:");
	  for(int i=0;i<r;i++) {
		  for(int j=0;j<c;j++) {
			  System.out.println("ar["+i+"]["+j+"]:");
		  	  ar[i][j]=sin.nextInt();
		  }
	  }
	  System.out.println("Array Values are");
	  for(int i=0;i<n;i++) {
		  for(int j=0;j<c;j++) {
			  System.out.print(ar[i][j]+" ");
		  }
		  System.out.println();
	  }
	}

}
