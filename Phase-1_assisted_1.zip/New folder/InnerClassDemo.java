//write a program in java to verify implementations of Inner classes
package deepic;

import java.util.Scanner;

public class InnerClassDemo{
	private int a;
	private int b;
	private int c;
	private int d;
	public InnerClassDemo(int a,int b,int c,int d){
	 this.a=a;
	 this.b=b;
	 this.c=c;
	 this.d=d;
	}
	public int pass() {
		if(a==1 &&b==2 &&c==3 &&d==4) {//outer class private members also accessible inside the inner class.
			class Inner{
				public void obtainID() {
					System.out.println("your ID:"+((a*2)+(b/2)+(c*2)+(d/2)));// id obtained when the input is 1234
				} 
			}
			Inner inc=new Inner();
			inc.obtainID();
		return 1;
		}
		else {
		System.out.println("OOPS you entered wrong password");
		return -1;
		}
	}
	public static void main(String[] args) {
		InnerClassDemo inn;
		int a,b,c,d,i=2,counter=0;
		while(i>=0) {
			Scanner sin=new Scanner(System.in);
			System.out.println("Enter password(Four Digit) To open the lock then obtain ID ");
			System.out.println("Enter 1st digit: ");
			a=sin.nextInt();
			System.out.println("Enter 2nd digit: ");
			b=sin.nextInt();
			System.out.println("Enter 3rd digit: ");
			c=sin.nextInt();
			System.out.println("Enter 4th digit: ");
			d=sin.nextInt();
			inn=new InnerClassDemo(a,b,c,d);
		    if(inn.pass()==1) {
			   System.out.println("Successfully...");
			   counter=1;
			   break;
		   }
		    i--;
		    System.out.println("your no of attempts left:"+(i+1));
		}
		
		if(counter==0){
			   System.out.println("you are  Blocked..."); 
		   }	   
	
	}
}
