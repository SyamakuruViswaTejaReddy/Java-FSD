//To create,read,update and delete operations on the files in java.
package Multexc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class CreReaUpdDel {
	public static void createFileUsingFileClass()throws IOException{
		
		File file=new File("C:\\Users\\syama\\Documents\\viswa\\files\\cre.txt");
		if(file.createNewFile()) {
			System.out.println("File created");
		}
		else {
			System.out.println("File already exist...");
		}
		FileWriter writer=new FileWriter(file,false);
		writer.write("hii hello.....");
		writer.close();
		
	}
	public static void readFileReaderClass() throws IOException
	{ 
		FileReader reader= new FileReader("C:\\Users\\syama\\Documents\\viswa\\files\\cre.txt");
		
		int data;
		
		while((data=reader.read())!=-1){
			
			System.out.print((char)data);
		}
		
	}
	public static void modifyFile(String file, String olddata,String newdata) {
		
		File fileToBeModified= new  File(file);
		String fileData="";
		BufferedReader reader=  null;
		FileWriter writer=null;
		try {
			reader= new BufferedReader(new FileReader(fileToBeModified));
			String line= reader.readLine();
			while(line!=null) {
				fileData= fileData+line+System.lineSeparator();
				line=reader.readLine();
			}
			String newFiledata= fileData.replaceAll(olddata, newdata);
			writer = new FileWriter(fileToBeModified);
			writer.write(newFiledata);
			System.out.println("Data Updated Successfully");
		}
		catch (Exception e) {
			System.out.println("Error: "+e);
		}
		finally {
			
			try {
				reader.close();
				writer.close();
				
				System.out.println("Reader and Writter Closed");
				
			} catch (IOException e2) {
				System.out.println("Error: "+e2);
			}
			
		}
		
	}

	public static void main(String[] args) {
		while(true) {
			System.out.println("File Operations");
			System.out.println("1.create 2.read 3.update 4.delete exit(press any key)");
			Scanner sin=new Scanner(System.in);
			int i=sin.nextInt();
			if(i==1) {
				try {
					createFileUsingFileClass();
				}
				catch(IOException e) {
					System.out.println("Exception:"+e);
				}
        	}
			else if(i==2) {
				try {
					readFileReaderClass();
				} 
				catch (IOException e) {
					System.out.println("File not available"+e);
				}
			}
		    else if(i==3) {
		    	try {
					modifyFile("C:\\Users\\syama\\Documents\\viswa\\files\\cre.txt", "hii", "Hey");
				} catch (Exception e) {
					// TODO: handle exception
					System.out.println("Error: "+e);
				}
		    }
		    else if(i==4) {
		    	try {
					Path path= Paths.get("C:\\Users\\syama\\Documents\\viswa\\files\\cre.txt");
					if(Files.deleteIfExists(path))
						System.out.println("File  deleted");
					else
						System.out.println("File not Deleted");
				} catch (DirectoryNotEmptyException e) {
					// TODO: handle exception
					System.out.println("Directory is not empty");
				}
				catch (IOException e) {
					// TODO: handle exception
					System.out.println("Invalid Permission");
				}
		    }
			else {
				System.out.println("Exit...");
				break;
			}
		}
	}
}
