//Create a Thread by Implementing 'Runnable' Interface
package Multexc;

public class ThreadRunnable implements Runnable{

	public void run() {
		System.out.println("thread Running...");
	}
	public static void main(String[] args) {
	
		ThreadRunnable tr=new ThreadRunnable();
		ThreadRunnable tr1=new ThreadRunnable();
		Thread t=new Thread(tr);
		Thread t1=new Thread(tr1);
		t.start();
		t1.start();
	}

}
