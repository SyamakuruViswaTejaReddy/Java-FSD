//Create a Thread by Extending 'Thread' class
package Multexc;

public class ThreadDemo extends Thread{
	
	public void run() {
		System.out.println("Thread is running...");
	}
	public static void main(String[] args) {
		ThreadDemo th=new ThreadDemo();
		ThreadDemo th1=new ThreadDemo();
		th.start();
		th1.start();

	}

}
