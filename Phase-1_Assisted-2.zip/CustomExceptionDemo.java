//Custom Exception
package Multexc;

public class CustomExceptionDemo {
	    public void division(int a,int b) throws ArithmeticException  
	    {  
	        System.out.println("Inside the method()");  
	        int c=a/b;
	        //throw new ArithmeticException("throwing ArithmeticException");
	    }  

	public static void main(String[] args) {
		
		CustomExceptionDemo cus=new CustomExceptionDemo();		
		try  
        {  
          cus.division(10,0);  
        }  
        catch(ArithmeticException e)  
        {  
            System.out.println("caught in main() method");  
        }  
		finally {
			System.out.println("At last Finally Execucted...");
		}

	}

}
