//Demonstrate Synchronization
package Multexc;

public class SynchronizationDemo {

 	public static void main(String[] args) {
        Game obj=new Game();
 		Player1 p1=new Player1(obj);
 		Player2 p2=new Player2(obj);
 		p1.start();
 		p2.start();
		
	}

}
