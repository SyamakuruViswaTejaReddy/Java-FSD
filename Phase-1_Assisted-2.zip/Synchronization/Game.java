package Multexc;

public class Game {
	synchronized public void PlayGame(int n) {
		System.out.println("I am the Thread"+n);
		System.out.println("My task is Completed...");		
		
	}

}
