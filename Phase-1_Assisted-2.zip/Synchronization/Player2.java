package Multexc;

public class Player2 extends Thread{

	Game g;
	 public Player2(Game g) {
		 this.g=g;
	 } 
	 public void run() {
		 g.PlayGame(2);
	 }
}
