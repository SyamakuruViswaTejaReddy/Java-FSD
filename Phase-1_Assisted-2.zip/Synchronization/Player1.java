package Multexc;

public class Player1 extends Thread {
     Game g;
	 public Player1(Game g) {
		 this.g=g;
	 } 
	 public void run() {
		 g.PlayGame(1);
	 }
}
