package Multexc;

public class EncapsulationDemo {
	 private String eName;
	 private int eid;
	 private int salary;
	 public int getEid(){
		 return eid;
	 }
	 public String getEname(){
		 return eName;
	 }
	 public int getSalary(){
		 return salary;
	 }
	 public void setEid(int eid){
		 this.eid = eid; 
	 }
	 public void setEname(String eName){
	   this.eName = eName;
	 }
	 public void setSalary(int Salary){
		 this.salary = Salary;
	 }
}
