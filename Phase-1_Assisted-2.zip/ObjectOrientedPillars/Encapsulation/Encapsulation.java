//Encapsulation
package Multexc;

public class Encapsulation {

	public static void main(String[] args) {
		EncapsulationDemo e = new EncapsulationDemo();
        e.setEname("Earth");
        e.setEid(01);
        e.setSalary(100000);
        System.out.println("Employee ID:" +e.getEid());
        System.out.println("Employee Name:" + e.getEname());
        System.out.println("Employee Salary:" + e.getSalary());

	}

}
