package Multexc;

abstract class Abstraction {
   
	abstract void way(); 
	
}
