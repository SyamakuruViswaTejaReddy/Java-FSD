package Multexc;

public class Aeroplane extends Abstraction {

	 void way() {
		System.out.println("Air way");
	}
}
