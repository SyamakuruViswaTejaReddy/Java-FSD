package Multexc;

public class Bus extends Abstraction{

	 void way() {
		System.out.println("Road way");
	}
}
