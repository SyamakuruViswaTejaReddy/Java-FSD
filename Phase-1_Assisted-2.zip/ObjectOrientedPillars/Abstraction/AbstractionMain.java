//Abstraction
package Multexc;

public class AbstractionMain {

	public static void main(String[] args) {
	
		Abstraction b=new Bus();
		b.way();
		Abstraction s=new Ship();
		s.way();
		Abstraction a=new Aeroplane();
		a.way();

	}

}
