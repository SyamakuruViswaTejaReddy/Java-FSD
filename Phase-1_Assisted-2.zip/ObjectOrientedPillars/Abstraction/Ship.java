package Multexc;

public class Ship extends Abstraction{

	void way() {
		System.out.println("Water way");
	}
}
