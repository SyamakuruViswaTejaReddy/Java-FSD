package Multexc;

public class InheritanceA {
	public void displayA() {
		System.out.println("From Base Class");
	}
}
