//Inheritance
package Multexc;

public class InheritanceB extends InheritanceA {
	public void displayB() {
		System.out.println("From Derived Class");
	}
	public static void main(String[] args) {
		
		InheritanceB inh=new InheritanceB();
		inh.displayA();
		inh.displayB();

	}

}
