package Multexc;

public class PolymorphismDemo {
	
	public void display() {
		System.out.println("From Base Class");

	}
}
