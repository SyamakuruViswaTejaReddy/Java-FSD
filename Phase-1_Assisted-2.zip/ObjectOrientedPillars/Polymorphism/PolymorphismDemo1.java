//Polymorphism
package Multexc;

public class PolymorphismDemo1 extends PolymorphismDemo{
	public void display() {       //Runtime
		System.out.println("From Derived Class");
	}
	public static void main(String[] args) {
		
		PolymorphismDemo pd=new PolymorphismDemo1();
		pd.display();            //It binds at Runtime.
	}

}
