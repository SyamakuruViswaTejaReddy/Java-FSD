//Diamond problem using oops concept
package Multexc;

public class Diamond implements A,B{

	public void fun() {
		A.super.fun();
		B.super.fun();
	}
	public static void main(String[] args) {
		Diamond d=new Diamond();
		d.fun();

	}

}
