package Multexc;

public interface A {
    	
	default  void fun() {
		System.out.println("A Interface Method");
	}
}
