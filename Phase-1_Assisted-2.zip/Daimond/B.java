package Multexc;

public interface B {
	
	default  void fun() {
		System.out.println("B Interface Method");
	}
}
