//To demonstrate sleep() and wait()
package Multexc;

public class SleepWaitDemo{
	
	private static Object Lock=new Object();

	public static void main(String[] args) {
		
		try {
			Thread.sleep(2000);
			System.out.println(Thread.currentThread().getName()+ " is  woke up after "
					+ "2 second  of  sleep");
			synchronized(Lock) {
				Lock.wait(3000);
				System.out.println("Object is woke up after wait of  3 seconds");
			}
		}
		catch(InterruptedException e){
            e.printStackTrace();
			System.out.println("Error Occured: "+e);
		}

	}

}
