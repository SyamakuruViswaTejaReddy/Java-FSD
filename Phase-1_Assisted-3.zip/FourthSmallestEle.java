//To find the fourth smallest element
package DsArrLists;

import java.util.Arrays;
import java.util.Scanner;

public class FourthSmallestEle {

	public static void main(String[] args) {
	 
		 int n;
		 Scanner sin=new Scanner(System.in);
		 System.out.println("Enter array Size:");
		 n=sin.nextInt();
		 int[] arr=new int[n];
		 System.out.println("Enter array values:");
		 for (int i=0; i<n;i++) {
				System.out.print("arr["+i+"]:");
				arr[i]=sin.nextInt();
			}
		 sin.close();
		 System.out.println("Array values before sorting:");
		 for (int i=0; i<arr.length;i++) {
				System.out.print(arr[i]+ " ");
			}
		 Arrays.sort(arr);
		 System.out.println("\nArray values after  sorting:");
		 for (int i=0; i<arr.length;i++) {
				System.out.print(arr[i]+ " ");
			}
		 System.out.println("\n4th Smallest element in array is:"+arr[3]);
	}

}
