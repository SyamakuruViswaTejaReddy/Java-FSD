package DsArrLists;

import java.util.Scanner;

public class MultiplyTwoMatrices {

	public static void main(String[] args) {
		 int r1,c1,r2,c2; 
		 int c[][];
		 Scanner sin=new Scanner(System.in);
		 System.out.println("Matrix 1:");
		 System.out.println("Enter row Size:");
		 r1=sin.nextInt();
		 System.out.println("Enter coloumn Size:");
		 c1=sin.nextInt();
		 int[][] arr=new int[r1][c1];
		 System.out.println("Enter Matrix 1 values:");
		 for (int i=0; i<r1;i++) {
			 for (int j=0; j<c1;j++) {
				System.out.print("arr["+i+"]["+j+"]:");
				arr[i][j]=sin.nextInt();
			} 
		 }
		 System.out.println("Matrix 1 values are:");
		 for (int i=0; i<r1;i++) {
			 for (int j=0; j<c1;j++) {
				System.out.print(arr[i][j]+ " ");
			}
			 System.out.println();
		 }
		 System.out.println("Matrix 2:");
		 System.out.println("Enter row Size:");
		 r2=sin.nextInt();
		 System.out.println("Enter coloumn Size:");
		 c2=sin.nextInt();
		 int[][] arr1=new int[r2][c2];
		 System.out.println("Enter Matrix 2 values:");
		 for (int i=0; i<r2;i++) {
			 for (int j=0; j<c2;j++) {
				System.out.print("arr["+i+"]["+j+"]:");
				arr1[i][j]=sin.nextInt();
			} 
		 }
		 System.out.println("Matrix 2 values are:");
		 for (int i=0; i<r1;i++) {
			 for (int j=0; j<c1;j++) {
				System.out.print(arr1[i][j]+ " ");
			}
			 System.out.println();
		 }
		 c=new int[r1][c2];
		 if(c1==r2) {
			 System.out.println("Multiplication of Two Matrices:");
			 for (int i=0; i<r1;i++) {
				 for (int j=0; j<c2;j++) {
					 c[i][j]=0;
					 for(int k=0;k<c1;k++) {
						 c[i][j]=c[i][j]+arr[i][k]*arr1[k][j];
					 } 
					System.out.println(c[i][j]+" ");
				}
				System.out.println();
			 }
		 }
		 else {
			 System.out.println("Multiplication of Two Matrices cannot be possible...");
		 }
        
	}

}
