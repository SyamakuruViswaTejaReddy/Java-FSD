//java program to delete first occurrence of a key in a single linkedlist
package DsArrLists;

import java.util.LinkedList;
import org.w3c.dom.Node;
public class SingleLinkedList {

	Node head;
	static class Node{
		int data;
		Node next;
		
		Node(int d){
			data=d;
			next=null;
		}
	}
	public static SingleLinkedList insert(SingleLinkedList list,int data) {
	
		Node new_node= new Node(data);
		new_node.next=null;
		if(list.head==null) {
			list.head=new_node;//if Linked list is empty then new node is a head		
		}
		else {
			Node last=list.head;
			while(last.next!=null) {
				last =last.next;//traverse for last node
			}
			last.next=new_node;
		}
		
		return list;
	}
	
	
	public static void printList(SingleLinkedList list) {
		
		Node currNode= list.head;
		System.out.print("LinkedList: ");
		while(currNode!=null) {
			System.out.print(currNode.data +" ");
			currNode=currNode.next;
		}
		
		System.out.println();
	}
	public static SingleLinkedList deleteByKey(SingleLinkedList list, int key) {
		
			Node currNode = list.head, prev = null;
			if (currNode != null && currNode.data == key) {
				list.head = currNode.next; // Changed head(deleting first node)
				System.out.println(key + " found and deleted");
				return list;
			}
			while (currNode != null && currNode.data != key) {
				prev = currNode;
				currNode = currNode.next;
			} 
			if (currNode != null) {
				prev.next = currNode.next;
				System.out.println(key + " found and deleted");
			}
			//if key not found
			if (currNode == null) {
				System.out.println(key + " not found");
			}
			return list;
		}
	public static void main(String[] args) {
	
        SingleLinkedList list =new SingleLinkedList();
		list= insert(list,10);
		list=  insert(list,22);
		list= insert(list, 35);
		list= insert(list, 42);
		list= insert(list, 56);
		list= insert(list, 62);
		list= insert(list, 76);
		list= insert(list, 82);
		printList(list);
		deleteByKey(list, 42);
		printList(list);
		
	}

}
