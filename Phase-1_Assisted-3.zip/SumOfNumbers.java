//To find sum of n numbers of elements in range l and r
package DsArrLists;

import java.util.Scanner;

public class SumOfNumbers {

	public static void main(String[] args) {
		 int n,l,r,sum=0;
		 Scanner sin=new Scanner(System.in);
		 System.out.println("Enter array Size:");
		 n=sin.nextInt();
		 int[] arr=new int[n];
		 System.out.println("Enter array values:");
		 for (int i=0; i<n;i++) {
				System.out.print("arr["+i+"]:");
				arr[i]=sin.nextInt();
			}
		 System.out.println("Array values are:");
		 for (int i=0; i<arr.length;i++) {
				System.out.print(arr[i]+ " ");
			}
		 System.out.println("\nSum of elements between the range:");
		 System.out.println("Enter the low:");
		 l=sin.nextInt();
		 System.out.println("Enter array high:");
		 r=sin.nextInt();
		 if(r<=n) {
			 for (int i=l; i<=r;i++) {
				 sum=sum+arr[i];
			 }
			 System.out.println("Sum of elements:"+sum); 
		 }
		 else {
			 System.out.println("You are exceeding the range...");
		 }
	}

}
