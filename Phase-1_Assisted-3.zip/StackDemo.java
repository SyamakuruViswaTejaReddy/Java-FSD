//java program to insert and remove elements in stack 
package DsArrLists;

public class StackDemo {

	static final int MAX=1000;
	int  top;
	int a[]= new int[MAX];
	
	boolean isEmpty() {
		
		return top<0;
		
	}
	
	public StackDemo() {
		top=-1;//stack is empty;
	}
	boolean push(int x) {  //push element into stack
		if(top>=(MAX-1)) {
			System.out.println("Stackis Overflow");
			return false;
		}
		else {
			a[++top]=x;
			System.out.println(x+" Pushed insto stack");
			return true;
		}
	}
	int pop() {    //pop the element out from the stack
		
		if(top<0) {
			System.out.println("Statck  is UNDERFLOW");
			return 0;
		}
		else {
			int x= a[top--];
			return x;
		}
		
	}
	
	public static void main(String[] args) {
		StackDemo s=  new StackDemo();
		s.push(10);
		s.push(20);
		s.push(30);
		s.push(40);
		
		System.out.println(s.pop()+ " : Poped Out from stack");
	}

}
