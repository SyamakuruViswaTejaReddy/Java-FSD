//Write a program in java to right rotate an array by 5 steps
package DsArrLists;

import java.util.Scanner;

public class Arrayrotation {
	public void rotate(int num[],int k) {
	if(k> num.length) {
		k= k% num.length; 
		int result[] = new int[num.length];
		for(int i=0; i<k; i++) {
				result[i]= num[num.length-k+i];
		}
		int j=0;
		for(int i=k; i<num.length;i++) {
			result[i]=num[j];
			j++;
		}
		System.arraycopy(result, 0, num, 0, num.length);
			
		}
	}
   public static void main(String[] args) {
	 int n,r;
	 Arrayrotation a=new Arrayrotation();
	 Scanner sin=new Scanner(System.in);
	 System.out.println("Enter array Size:");
	 n=sin.nextInt();
	 int[] arr=new int[n];
	 System.out.println("Enter array values:");
	 for (int i=0; i<n;i++) {
			System.out.print("arr["+i+"]:");
			arr[i]=sin.nextInt();
		}
	 System.out.println("Array values before rotation:");
	 for (int i=0; i<arr.length;i++) {
			System.out.print(arr[i]+ " ");
		}
	 System.out.println("\nEnter how many steps to rotate:");
	 r=sin.nextInt();
	 a.rotate(arr,n+r);
	 System.out.println("Array values after rotation:");
	 for (int i=0; i<arr.length;i++) {
			System.out.print(arr[i]+ " ");
		}
 }
}
