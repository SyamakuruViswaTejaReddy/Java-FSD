//Write a program in java implementing the Linear search algorithm
package DSSortingSearching;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		 int n;
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter array Size:");
		 n=sc.nextInt();
		 int[] arr=new int[n];
		 System.out.println("Enter array values:");
		 for (int i=0; i<n;i++) {
				System.out.print("arr["+i+"]:");
				arr[i]=sc.nextInt();
		}
		 System.out.println("Array values are:");
		 for (int i=0; i<arr.length;i++) {
				System.out.print(arr[i]+ " ");
		}
	        
	        System.out.println("\nEnter the Element to  be Searced:");
	        
	        int SearchValue= sc.nextInt();
	        
	        int result= linearing(arr,SearchValue);
	        
	        if(result==-1) {
	            System.out.println("Element Not Found In The Array");
	        }
	        else {
	            System.out.println("Element Found at index: ["+result+"] , and Search  key is :"+arr[result]);
	        }
	        
	    }
	    
	    private static int linearing(int[] arr,int searchValue) {
	        
	                 
	        for(int i=0; i<arr.length; i++) {
	            
	            if(arr[i]==searchValue) {
	                return i;
	            }
	            
	        }
	        return -1;
	    }


	}

