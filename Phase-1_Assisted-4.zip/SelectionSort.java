//Write a program in java implementing the Selection sort
package DSSortingSearching;

import java.util.Scanner;

public class SelectionSort {

	public static void main(String[] args) {
		
		 int n;
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter array Size:");
		 n=sc.nextInt();
		 int[] arr=new int[n];
		 System.out.println("Enter array values:");
		 for (int i=0; i<n;i++) {
				System.out.print("arr["+i+"]:");
				arr[i]=sc.nextInt();
		}
		 System.out.println("Array values before sorting:");
		 for (int i=0; i<n;i++) {
				System.out.print(arr[i]+ " ");
		}
		selectionSort(arr,n);
	    System.out.println("\nThe sorted elements are:");
	    for(int i:arr){

	        System.out.print(i+" ");
	         }
	     }

	    public static void selectionSort(int[] arr,int n){

	        for(int i=0;i<n-1;i++){

	            int index =i;
	            
	            for(int j=i+1;j<n;j++){
	            	
	                if(arr[j]<arr[index]){

	                    index =j; 
	                }

	            }
	            int temp = arr[index];
	            arr[index]= arr[i];
	            arr[i]= temp;
	        }
	    }
}
