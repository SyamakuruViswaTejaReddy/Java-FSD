//Write a program in java implementing the Binary search algorithm
package DSSortingSearching;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		 int n;
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter array Size:");
		 n=sc.nextInt();
		 int[] arr=new int[n];
		 System.out.println("Enter array values:");
		 for (int i=0; i<n;i++) {
				System.out.print("arr["+i+"]:");
				arr[i]=sc.nextInt();
		}
		 System.out.println("Array values are:");
		 for (int i=0; i<arr.length;i++) {
				System.out.print(arr[i]+ " ");
		}
	        
	        System.out.println("\nEnter the Element to  be Searced:");
	        
	        int key= sc.nextInt();
		 try {
	            binarySearch(arr,0,key,n);
	        } catch (ArrayIndexOutOfBoundsException e) {
	            System.out.println("Error: "+e);
	        }
	        
	    }
	    private static void binarySearch(int[] arr, int lb, int key, int ub) {
	        
	        int midValue= (lb+ub)/2;
	        
	        while(lb<=ub) {
	            
	            if(arr[midValue]<key)
	            {
	                lb= midValue+1;
	            }
	            else if(arr[midValue]==key)
	            {
	                System.out.println("Element found at index: "+midValue);
	                break;
	            }
	            else {
	                ub=midValue-1;
	            }
	            midValue=(lb+ub)/2;
	        }
	        if(lb>ub) {
	            System.out.println("Element Not Found");
	        }
	        
	}

}
