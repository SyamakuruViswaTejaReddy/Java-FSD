package com.automation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleTitleCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String path="C:\\\\Users\\\\syama\\\\Downloads\\\\chromedriver_win32\\\\chromedriver.exe";
        System.setProperty("webdriver.chrome.driver", path);
        WebDriver driver=new ChromeDriver();
        String Url="http://www.google.com";
        driver.get(Url);
        System.out.println("Title:"+driver.getTitle());
        driver.close();
        System.out.println("Driver Working Properly");
	}

}
