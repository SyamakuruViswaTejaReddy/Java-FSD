package com.sp.exc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionHandlingSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
